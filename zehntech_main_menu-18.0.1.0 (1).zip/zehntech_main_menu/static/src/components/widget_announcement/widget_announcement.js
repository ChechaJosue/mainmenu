import { Component } from "@odoo/owl";

export class WidgetAnnouncement extends Component {}

WidgetAnnouncement.template = "zehntech_main_menu.WidgetAnnouncement";
